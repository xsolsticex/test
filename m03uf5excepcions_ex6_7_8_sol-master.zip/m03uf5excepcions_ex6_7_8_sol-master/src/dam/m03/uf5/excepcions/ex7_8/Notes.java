/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dam.m03.uf5.excepcions.ex7_8;

import static dam.m03.uf5.excepcions.ex7_8.Ex78.TECLASORTIR;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Classe que modela una BBDD de notes d'alumnes
 * @author manel
 */
public class Notes {
    
    // "base de dades" d'alumnes
    private static List<Alumne> alumnes = new ArrayList<>(100);

    public static List<Alumne> getAlumnes() {
        return alumnes;
    }

    public static void setAlumnes(List<Alumne> alumnes) {
        Notes.alumnes = alumnes;
    }
        
     /***
     * Demana les dades a l'usuari i retorna una entitat alumne
     * @return 
     */
    public static Alumne altaAlumno(){
        Alumne alu = null;
        Scanner sc = new Scanner(System.in);
        boolean sortir = false;
        
        String nom;
        
        // Dades matricula
        do{
            try{
                sortir = true;
                System.out.print("Nº matrícula (" + TECLASORTIR + " = sortir): ");
                String s = sc.next();
                if (! s.equals(TECLASORTIR))
                {
                    Integer mat = Integer.parseInt(s);
                    System.out.print("Nom alumne: ");
                    nom = sc.next();
                    
                    System.out.print("Edat: ");
                    Integer edat = Integer.parseInt(sc.next());
                    alu = new Alumne();
                    alu.setEdat(edat);
                    alu.setMatricula(mat);
                    alu.setNom(nom);
                }
            }catch(NumberFormatException ex1){
                System.out.println("Format de dades d'entrada no vàlid: " + ex1.getLocalizedMessage());
                sortir = false;
            } catch (Alumne.ExcepcionAlumno ex2) {
                System.out.println("Dades alumne incorrectes: " + ex2.getLocalizedMessage());
                sortir = false;
            }    
        }while(!sortir);
        
        do{
            try{
                if (alu != null)
                {
                    sortir = false;
                    System.out.print("Nota: (" + TECLASORTIR + " = sortir): ");
                    String s = sc.next();
                    if (! s.equals(TECLASORTIR))
                    {
                        Double nota = Double.parseDouble(s);
                        alu.addNota(nota);
                    }
                    else
                        sortir = true;
                }
            }catch(NumberFormatException ex1){
                System.out.println("Format de dades d'entrada no vàlid: " + ex1.getLocalizedMessage());
            } catch (Alumne.ExcepcionAlumno ex2) {
                System.out.println("Nota incorrecta: " + ex2.getLocalizedMessage());
            }    
        }while (!sortir);
        
        return alu;
    }
    
}
