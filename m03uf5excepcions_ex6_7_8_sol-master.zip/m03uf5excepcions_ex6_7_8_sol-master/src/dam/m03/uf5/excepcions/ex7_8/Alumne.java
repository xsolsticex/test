package dam.m03.uf5.excepcions.ex7_8;

import java.util.ArrayList;
import java.util.List;

public class Alumne {
    
    // constants
    public final int MIN_EDAT = 11;
    public final int MAX_EDAT = 16;
    public final int MIN_MAT = 1;
    public final int MAX_MAT = 10000;
    public final int MAXNOTES = 8;
    public final int MINNOTA = 0;
    public final int MAXNOTA = 10;
    
    //atributs
    private String nom;
    private int edat, matricula;
    private List<Double> notes;

    public Alumne() {
        notes = new ArrayList<>();
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getEdat() {
        return edat;
    }

    public void setEdat(int edat) throws ExcepcionAlumno {
        if (edat < MIN_EDAT || edat > MAX_EDAT)
            throw new ExcepcionAlumno("L'edat ha de ser entre " + MIN_EDAT + " i " + MAX_EDAT);
        this.edat = edat;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) throws ExcepcionAlumno {
         if (matricula < MIN_MAT || matricula > MAX_MAT)
            throw new ExcepcionAlumno("El id de matricula ha de ser entre " + MIN_MAT + " i " + MAX_MAT);
        this.matricula = matricula;
    }
    
    /***
     * Afegeix una nota a l'alumne, sempre que no arribi al limit de notes
     * La nota no pot ser menor que MIN_NOTA ni major que MAX_NOTA
     * @param nota
     * @throws dam.m03.uf5.excepcions.ej4y5.Alumne.ExcepcionAlumno 
     */
    public void addNota(double nota) throws ExcepcionAlumno
    {
        if (notes.size() >= MAXNOTES)
            throw new ExcepcionAlumno("S'ha arribat al màxim de " + this.MAXNOTES + " notes per l'alumne.");
        
        if (nota < this.MINNOTA || nota > MAXNOTA)
            throw new ExcepcionAlumno("La nota ha d'estar entre " + this.MINNOTA + " i " + this.MAXNOTA);
        
        notes.add(nota);
    }
    
    public double getNotaMitja()
    {
        
        int sum = 0;
        
        for (double n : notes)
            sum += n;
        
        //lambda:
        //return notes.stream().mapToDouble(d -> d).average()
        
        return (double)sum/notes.size();
    }
    
    public String getNotes()
    {
        String ret = "";
        
        for (Double i : notes)
            ret += i + ";";
        
        return ret;

    }

    @Override
    public String toString() {
        return "Nom: " + nom + System.lineSeparator()
                + "edat=" + edat +  System.lineSeparator()
                + "matricula=" + matricula + System.lineSeparator()
                + "notes= " + getNotes() + System.lineSeparator()
                + "nota mitja=" + getNotaMitja();
    }
        
    
    public class ExcepcionAlumno extends Exception{
        public ExcepcionAlumno(String msg){
            super(msg);
        }
        
        
}
    
}
