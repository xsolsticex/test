package dam.m03.uf5.excepcions.ex7_8;

public class Ex78 {
    
    public static final int MAXALUMNES = 100;
    public static final String TECLASORTIR = "S";
   
    /***
     * mètode principal que gestiona el menú principal
     * @param args 
     */
    public static void main(String[] args) {
        
        boolean fin = false;
        
        System.out.println("PROGRAMA DE GESTIÓ DE D'ALUMNES");
        
        for (int i = 0; i < MAXALUMNES && !fin; i++) 
        {
            System.out.println("NOU ALUMNE:");
            Alumne alum = Notes.altaAlumno();
            if(alum == null)
                fin = true;
            else{
                Notes.getAlumnes().add(alum);
                System.out.println();
                System.out.println("Afegit alumne:");
                System.out.println(alum);
                System.out.println();
            }
        }
        System.out.println("FI");
    }
}
