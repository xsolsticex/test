/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dam.m03.uf5.excepcions.ex6;

/**
 *
 * @author manel
 */
public class ValorsNoValidsException extends Exception {

    // constructor sense missatge
    public ValorsNoValidsException() {
    }

    // constructor amb missatge
    public ValorsNoValidsException(String message) {
        super(message);
    }
    
}
