/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dam.m03.uf5.excepcions.ex6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.PatternSyntaxException;

/**
 * Classe d'utilitat amb mètodes estàtics que realitzen funcions diverses
 * @author manel
 */
public class Utils {
    
    /***
     * En base a una llista de valors numèrics enters separats 
     * per un determinat caràcter, els retorna en una col.lecció
     * 
     * @param llistaString llista de valors enters, separats per un determinat separador. 
     * @param _s el caràcter separador. El separador no pot ser un dígit.
     * @return 
     */
    public static ArrayList<Integer> getNumbers(String llistaString, char _s) throws ValorsNoValidsException
    {
        List<String> strings;
        var separador = String.valueOf(_s);
        
        ArrayList<Integer> ret = new ArrayList<>();
        
        try {
            
             //verifiquem si el separador és un dígit
            if ("1234567890".contains(separador))
                throw new NumberFormatException("El separador no pot ser un dígit");
        
            // convertim a una llista d'estrings
            strings = Arrays.asList(llistaString.split(separador));

            //recorrem la llista de caracters
            for (String s : strings) {
                // els convertim a enters i alhora els entrem a la llista d'enters
                ret.add(Integer.parseInt(s));
            }            
        } catch (NumberFormatException | PatternSyntaxException ex) {
            // o bé el caràcter separador no és vàlid o bé els valors no són numèrics
            // rellencem de nou l'excepció com a 
            throw new ValorsNoValidsException(ex.getMessage());
        }
        
        return ret;
    }
    
}
