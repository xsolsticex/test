package dam.m03.uf5.excepcions.ex6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Ex6 {
    
    public static void main(String[] args) {
        
        Scanner scan;
        
        String stringUsuari;
        
        Integer posIni = 0;
        
        Integer posFinal = 0;
        
        Integer resultat = 1;
        
        boolean ok = false;
        
        do
        {
        
            System.out.println("Entra una llista d'entre 2 i 10 enters, separats per un espai");

            try {
                //capturem l'entrada de l'usuari
                scan = new Scanner(System.in);
                stringUsuari = scan.nextLine();

                List<Integer> llistaValors = Utils.getNumbers(stringUsuari, ' ');

                System.out.println("Posició del nombre inicial: ");
                posIni = Integer.parseInt(scan.nextLine());

                System.out.println("Posició del nombre final: ");
                posFinal = Integer.parseInt(scan.nextLine());
                
                if (posIni >= posFinal)
                    throw new ValorsNoValidsException("El valor inicial no pot ser més gran que el vaor final" + posFinal + ":" + posIni);

                //recorrem array i multipliquem
                for (Integer i = posIni - 1; i <= posFinal - 1; i++) {

                    Integer n = llistaValors.get(i);

                    // ?: és un operador ternari. Permet simplificar un "if".
                    System.out.print(n + (i < posFinal - 1 ? " * " : ""));

                    resultat = resultat * n;
                }

                System.out.println(" = " + resultat);
                
                ok = true;

            } catch (ValorsNoValidsException n) {
                System.out.println("Els valors d'entrada no són correctes: " + n.getMessage());
            }
            catch (IndexOutOfBoundsException n) {
                System.out.println("La posició inicial o final és incorrecte: " + n.getMessage());
            }
        }
        while (!ok);
    }
}